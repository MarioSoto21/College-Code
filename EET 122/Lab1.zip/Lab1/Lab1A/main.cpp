#include <iostream>
using namespace std;
int main()
{
double area;
double b= 4.5;
double h= 10.5;
area=  .5*b*h;
cout<<"The area is:"<<area;
return 0;
}
