#include <iostream>
using namespace std;
int main()
{
    int result= 5;
    cout << "This code has multiple syntax errors \n";
    cout << "All the codes have been checked\n";
    cout << "Codes have been recompiled\n";
    cout << "Final result has been calculated correctly.\n";
    cout<< "result= " << result*3 << endl;
    cout << "Completed by Mario Soto.\n";
    return 0;

}

