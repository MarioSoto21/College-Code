/**
	A class for representing a microwave oven
**/
public class Microwave
{
	private int time;
	private int powerLevel;
	
	/**
		Creates a Microwave with 0 seconds on the timer an at low power (1)
	**/
	public Microwave()
	{
		time = 0;
		powerLevel = 1;
	}
	
	/**
		Increases the time on the timer by 30 seconds
	**/
	public void increaseTime()
	{
		time = time + 30;
	}
	
	/**
		Switches the power level from low to high
	**/
	public void switchPower()
	{
		if (powerLevel == 1)
		{
			powerLevel = 2;
		}
		else
		{
			powerLevel = 1;
		}
	}
	
	/**
		Resets the microwave to its initial state
	**/
	public void reset()
	{
		time = 0;
		powerLevel = 1;
	}
	
	/**
		Starts the microwave, displaying information about its cooking state
	**/
	public void start()
	{
			System.out.print("Cooking for " + time + " seconds ");
			System.out.println("at level " + powerLevel);
	}
	
	
}