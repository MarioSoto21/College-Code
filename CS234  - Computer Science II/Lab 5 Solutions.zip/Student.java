/*
 * A class to represent the quiz scores of a student
 */
import java.util.ArrayList;


public class Student {
	// Instance variables
    private String name;
    private ArrayList<Double> scores = new ArrayList<>();
   

    /**
     * Sets the name for the student
     * @param name 
     */
    public void setName(String name) {
        this.name = name;
    }
    
    
    /**
     * Gets the student's name
     * @return the student's name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Adds one quiz to the student's record
     * @param score the score of the quiz
     */
    public void addScore(double score)
    {
        scores.add(score);
    }
    
    /**
     * Returns the student's total score
     * @return the student's total score
     */
    public double getTotalScore()
    {
        double totalScores = 0.0;
        for (Double score: scores)
        {
            totalScores+=score;
        }
        return totalScores;    
    }
    
    /**
     * Calculates and returns the student's average quiz score
     * @return the student's average quiz score
     */
    public double getAverageScore()
    {
        if(scores.size() > 0)
        {
            return this.getTotalScore()/scores.size();
        }
        else
        {
            return 0;
        }
    }
    
    /**
     * Gets the highest score for this student
     * @return highest score
     */
    public double getHighScore()
    {
        double highScore = scores.get(0);
        for(int i=1;i<scores.size();i++)
        {
            if(scores.get(i) > highScore)
            {
                highScore = scores.get(i);
            }
        }
        return highScore;
    }
}
