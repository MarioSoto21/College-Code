Unzip file
open cmd
javac. filename.java
java filename